import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.TilePane;
import javafx.stage.Stage;


// The program purpose is to input a text dialogue and add it to the stage
public class JavaFXMain extends Application {
    
    // launch the application
    public void start(Stage s)
    {
        // set title for the stage
        s.setTitle("Program Input Table");
  
        // create a tile pane
        TilePane r = new TilePane();
  
        // create a text input dialog
        TextInputDialog td = new TextInputDialog("");
  
        // setHeaderText
        td.setHeaderText("Entr the input");
  
        // create a button
        Button d = new Button("Put Your input here");
  
        // create a event handler
        EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e)
            {
                // show the text input dialog
                td.show();
            }
        };
  
        // set on action of event
        d.setOnAction(event);
  
        // add button and label
        r.getChildren().add(d);
  
        // create a scene
        Scene sc = new Scene(r, 500, 300);
  
        // set the scene
        s.setScene(sc);
  
        s.show();
    }
  
    public static void main(String args[])
    {
        // launch the application
        launch(args);
    }
}
